import requests

# 🔑 Put your OpenRouter API key here
API_KEY = "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"

# Choose a free model (important)
MODEL = "nvidia/nemotron-3-ultra-550b-a55b:free"

SYSTEM_PROMPT = """
You are a helpful medical assistant chatbot.

Rules:
- Give ONLY general health information.
- Do NOT diagnose diseases.
- Do NOT prescribe medications.
- Do NOT give emergency treatment instructions.
- Always recommend consulting a doctor if needed.
- Use simple, friendly language.

Always end with:
"This is for educational purposes only and not a substitute for professional medical advice."
"""

dangerous_keywords = [
    "suicide",
    "kill myself",
    "self harm",
    "overdose",
    "die"
]

def safety_check(text):
    text = text.lower()
    for word in dangerous_keywords:
        if word in text:
            return False
    return True


def chat_with_model(user_input):

    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost",
        "X-Title": "Health Chatbot"
    }

    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_input}
        ]
    }

    response = requests.post(url, headers=headers, json=payload)

    data = response.json()

    # 🔴 DEBUG LINE (IMPORTANT)
    print("\nDEBUG RESPONSE:\n", data)

    return data["choices"][0]["message"]["content"]

print("💬 Health Chatbot started (type 'exit' to stop)")

while True:
    user_input = input("\nYou: ")

    if user_input.lower() == "exit":
        print("Bot: Bye 👋")
        break

    if not safety_check(user_input):
        print("Bot: ⚠️ Please seek help from a healthcare professional immediately.")
        continue

    try:
        reply = chat_with_model(user_input)
        print("\nBot:", reply)
    except Exception as e:
        print("Error:", e)