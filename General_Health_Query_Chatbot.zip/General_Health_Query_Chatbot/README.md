# Health Chatbot (LLM Based)

## Description
A simple health chatbot using OpenRouter API with prompt engineering and safety filters.

## Features
- General health Q&A
- Safety filtering for harmful queries
- Prompt-engineered medical assistant behavior

## How to Run
1. Install dependencies:
   pip install requests

2. Add API key in health_chatbot.py

3. Run:
   python health_chatbot.py