from src.data_fetcher import fetch_stock_data
from src.preprocessing import prepare_data
from src.model import train_model
from src.visualization import plot_results

from sklearn.metrics import mean_absolute_error
from sklearn.metrics import r2_score


stock = fetch_stock_data()

X, y = prepare_data(stock)

model, X_test, y_test, predictions = train_model(X, y)

mae = mean_absolute_error(y_test, predictions)
r2 = r2_score(y_test, predictions)

print("Mean Absolute Error:", mae)
print("R2 Score:", r2)

plot_results(y_test, predictions)