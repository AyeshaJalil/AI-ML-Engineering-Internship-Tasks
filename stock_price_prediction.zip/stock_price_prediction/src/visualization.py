import matplotlib.pyplot as plt

def plot_results(actual, predicted):

    plt.figure(figsize=(12,6))

    plt.plot(actual.values, label="Actual Price")
    plt.plot(predicted, label="Predicted Price")

    plt.title("Actual vs Predicted Closing Prices")

    plt.xlabel("Days")
    plt.ylabel("Price")

    plt.legend()

    plt.show()