import yfinance as yf

def fetch_stock_data():
    stock = yf.download(
        "TSLA",
        start="2020-01-01",
        end="2025-01-01"
    )

    return stock