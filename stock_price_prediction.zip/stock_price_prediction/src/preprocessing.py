def prepare_data(stock):

    stock['Next_Close'] = stock['Close'].shift(-1)

    stock.dropna(inplace=True)

    X = stock[['Open', 'High', 'Low', 'Volume']]
    y = stock['Next_Close']

    return X, y