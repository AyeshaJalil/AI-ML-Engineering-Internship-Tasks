# Stock Price Prediction

This project predicts the next day's closing stock price using historical stock market data from Yahoo Finance.

## Technologies Used

- Python
- Pandas
- YFinance
- Scikit-Learn
- Matplotlib

## Model

Linear Regression

## Features

- Open
- High
- Low
- Volume

## Target

Next Day Closing Price

## Run

python stock_prediction.py